#AA tech pre
lizihan
---

# 0. Setup
## Things we are going to use:
* XAMPP
* Github (Desktop version)

## Language we are going to learn:
* php (with sql, using mysql)
* bootstrap (with HTML javascript css)

Put files under xampp/htdocs to see results.

# 1. Contents

Things like:

+ documents
+ calendar to show events
+ home page profile of the organization
+ apply for UMSJTU-AA

    * login
    * fill forms
    * upload files
    
+ chat?
+ management people

    * login
    * announcement
    * profile
	
+ email-sending
+ management tools


---
+ home page
+ management page
